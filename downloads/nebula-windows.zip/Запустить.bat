@echo off
rem ===== Nebula Messenger — запуск =====
start "" "%~dp0index.html"